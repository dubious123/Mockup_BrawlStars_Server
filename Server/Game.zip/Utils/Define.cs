﻿
public static partial class Define
{
	public static readonly sfloat FixedDeltaTime = (sfloat)1f / (sfloat)60f;
}
