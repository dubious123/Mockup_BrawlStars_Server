﻿
namespace Server.Game
{
	public interface INetUpdatable
	{
		public void Update();
	}
}
