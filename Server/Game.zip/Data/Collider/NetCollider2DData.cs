﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server.Game.Data
{
	public class NetCollider2DData
	{
		public int Type { get; init; }
		public sVector2 Offset { get; init; }
	}
}
