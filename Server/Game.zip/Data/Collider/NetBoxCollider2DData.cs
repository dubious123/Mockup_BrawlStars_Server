﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server.Game.Data
{
	public class NetBoxCollider2DData : NetCircleColllider2DData
	{
		public sfloat Radius { get; set; }
	}
}
