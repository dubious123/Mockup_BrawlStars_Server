﻿namespace Server.Game.Data
{
	public class NetCircleColllider2DData : NetCollider2DData
	{
		public sVector2 Size { get; init; }
	}
}
