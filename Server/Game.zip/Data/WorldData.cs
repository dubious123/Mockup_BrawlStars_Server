﻿
using System.Collections.Generic;

namespace Server.Game.Data
{
	public class WorldData
	{
		public NetObjectData[] NetObjectDatas;

		public sVector3[] SpawnPoints;
	}
}
