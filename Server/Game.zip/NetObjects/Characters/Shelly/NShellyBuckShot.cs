using System.Collections;
using System.Collections.Generic;

using Server.Game;


public class NShellyBuckShot : INetBaseSkill
{
	public int Id { get; init; }
	public NetCharacter Character => _shelly;
	public bool Performing { get; set; }
	public bool Active { get; set; }
	public bool BtnPressed { get; private set; }
	public int AmmoCount => _ammoCount;
	public int BulletAmountPerAttack => _bulletAmountPerAttack;
	public sfloat BulletAngle => _bulletAngle;
	public LinkedList<NetProjectile[]> AliveBulletArrArr;
	public Queue<NetProjectile[]> BulletArrQueue { get; private set; }

	private IEnumerator<int> _coHandler;
	private readonly NCharacterShelly _shelly;
	private readonly HitInfo _hitInfo;
	private int _ammoCount, _maxAmmoCount, _bulletAmountPerAttack, _reloadFrame, _currentReloadDeltaFrame,
		_waitFrameBeforePerform, _waitFrameAfterPerform, _bulletMaxTravelTime;
	private sfloat _bulletCollisionRange, _bulletSpeed, _bulletAngle;



	public NShellyBuckShot(NCharacterShelly character)
	{
		_shelly = character;
		Id = 0x11;
		_maxAmmoCount = 3;
		_ammoCount = _maxAmmoCount;
		_bulletAmountPerAttack = 5;
		_reloadFrame = 60;
		_waitFrameBeforePerform = 10;
		_waitFrameAfterPerform = 10;
		_bulletMaxTravelTime = 48;
		_bulletCollisionRange = (sfloat)0.2f;
		_bulletSpeed = (sfloat)8 / (sfloat)_bulletMaxTravelTime;
		_bulletAngle = (sfloat)30f;
		_hitInfo = new HitInfo()
		{
			Damage = 20,
		};

		AliveBulletArrArr = new();
		BulletArrQueue = new Queue<NetProjectile[]>(_maxAmmoCount);
		for (int i = 0; i < _maxAmmoCount; i++)
		{
			var arr = new NetProjectile[_maxAmmoCount];
			for (int j = 0; j < _bulletAmountPerAttack; ++j)
			{
				arr[j] = new NetProjectile(_shelly, _bulletCollisionRange, _bulletSpeed, _hitInfo, _bulletMaxTravelTime);
			}

			BulletArrQueue.Enqueue(arr);
		}
	}

	void INetUpdatable.Update()
	{
		if (Performing is true)
		{
			_coHandler.MoveNext();
		}

		UpdateBullets();

		if (_ammoCount <= _maxAmmoCount && _currentReloadDeltaFrame < _reloadFrame)
		{
			++_currentReloadDeltaFrame;
			return;
		}

		_currentReloadDeltaFrame = 0;
		++_ammoCount;
	}

	public void HandleInput(in InputData input)
	{
		var nowPressed = (input.ButtonInput & 0) == 1;
		if (BtnPressed is true && nowPressed is false && _ammoCount >= 0)
		{
			_shelly.SetActiveOtherSkills(this, false);
			Performing = true;
			_coHandler = Co_Perform();
			--_ammoCount;
			return;
		}

		BtnPressed = nowPressed;
	}

	public IEnumerator<int> Co_Perform()
	{
		for (int i = 0; i < _waitFrameBeforePerform; i++)
		{
			yield return 0;
		}

		var bullets = BulletArrQueue.Dequeue();
		AliveBulletArrArr.AddLast(bullets);
		foreach (var bullet in bullets)
		{
			bullet.Reset(_shelly.Position, _shelly.Rotation);
		}

		for (int i = 0; i < _waitFrameAfterPerform; i++)
		{
			yield return 0;
		}

		_shelly.SetActiveOtherSkills(this, true);
		Performing = false;
		yield break;
	}

	public void UpdateBullets()
	{
		for (var arr = AliveBulletArrArr.First; arr is not null;)
		{
			bool isDead = true;
			for (int j = 0; j < _bulletAmountPerAttack; j++)
			{
				var bullet = arr.Value[j];
				if (bullet.IsAlive)
				{
					bullet.Update();
					isDead = false;
					continue;
				}
			}

			if (isDead)
			{
				BulletArrQueue.Enqueue(arr.Value);
				var remove = arr;
				arr = arr.Next;
				AliveBulletArrArr.Remove(remove);
			}

			arr = arr.Next;
		}
	}

	public void Cancel()
	{
		throw new System.NotImplementedException();
	}
}
