using System.Collections.Generic;

using Server.Game;

using static Enums;

public class NetProjectile : INetUpdatable
{
	public NetCharacter Owner { get; set; }
	public bool IsAlive { get; private set; }
	public sVector3 Position { get; set; }
	public sQuaternion Rotation { get; set; }
	public sfloat Speed { get; set; }
	public INetCollider2D Collider { get; init; }

	private sfloat _sqrRange;
	private readonly HitInfo _hitInfo;
	private readonly int _maxTravelTime;
	private int _currentTravelTime;

	public NetProjectile(NetCharacter character, sfloat range, sfloat speed, HitInfo hitInfo, int maxTravelTime)
	{
		Owner = character;
		_sqrRange = range * range;
		_hitInfo = hitInfo;
		Speed = speed;
		_maxTravelTime = maxTravelTime;
		_currentTravelTime = 0;
		Disable();
	}

	public void Disable()
	{
		IsAlive = false;
	}

	public void Reset(sVector3 pos, sQuaternion rot)
	{
		IsAlive = true;
		Position = pos;
		Rotation = rot;
	}

	public void Update()
	{
		if (IsAlive == false)
		{
			return;
		}

		if (_currentTravelTime >= _maxTravelTime)
		{
			Disable();
			return;
		}

		Position += Rotation * sVector3.forward * Speed;
		Owner.World.FindAllAndBroadcast(target =>
		{
			if (Owner.World.GameRule.CanSendHit(Owner, target) is true)
			{
				return (target.Position - Owner.Position).sqrMagnitude <= _sqrRange;
			}

			return false;
		}, target =>
		{
			Owner.SendHit(target as ITakeHit, _hitInfo);
		});

		++_currentTravelTime;
	}
}
